@extends('master') 
 
@section('konten')
<header>
	<div class="navbar" role="navigation">
		<div class="container">
    	<div class="navbar-header">
      </div>
      <div class="collapse navbar-collapse" id="mynav">
      	<ul class="nav navbar-nav navbar-right">
        	<li><a href="#about">About</a></li>
          <li><a href="#clients">Clients</a></li>
          <li><a href="#process">Process</a></li>
          <li><a href="#testimonials">Testimonials</a></li>
          <li><a href="#blogs">Blogs</a></li>
        </ul>
      </div>
     </div>	
	</div>
  
  </div>
 </header>
  
<div class="container-fluid" style="font-family: Arial, Helvetica, sans-serif;">
    <div class="col-md-12" style="padding:1%;"></div>

        <div class="col-md-12 selanjutnya">
            <img src="../image/icpc.png" style="">
                <h2 style="color: darkorange;">Finalist ICPC 2019</h2>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi cum aspernatur maxime officiis voluptates iusto magni facere nostrum, reprehenderit commodi qui. Similique voluptas blanditiis consequatur cupiditate, nihil voluptate perspiciatis mollitia?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil nulla est explicabo sed consequatur illo earum vel autem provident totam at dignissimos, magnam pariatur blanditiis veniam quod ducimus mollitia dolorum.
                </p>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi cum aspernatur maxime officiis voluptates iusto magni facere nostrum, reprehenderit commodi qui. Similique voluptas blanditiis consequatur cupiditate, nihil voluptate perspiciatis mollitia?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil nulla est explicabo sed consequatur illo earum vel autem provident totam at dignissimos, magnam pariatur blanditiis veniam quod ducimus mollitia dolorum.
                </p>
                <hr>
            <a href="/prestasi">Kembali</a>
            <hr>
        </div>
    
</div>
 
@endsection