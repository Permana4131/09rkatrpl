<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\programKegiatan;

class programKegiatanController extends Controller
{
    //
}
