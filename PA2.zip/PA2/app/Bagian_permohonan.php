<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bagian_permohonan extends Model
{
    protected $table = "bagian_permohonan";
    public $timestamps = false;
}
