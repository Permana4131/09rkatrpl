 
 
<?php $__env->startSection('konten'); ?>
<script>
$(document).ready(function(){
  $("cari").click(function(){
    $("p").toggle(1000);
  });
});

var cari = ()=>
$(document).ready(function(){
    var inCari = document.getElementById('inCari').value;
   if(inCari!=""){  
         $(".tambahProgram").hide(800);
        $(".test15").show(800);  
   }else{
        alert("Data Tidak Ditemukan");
   }
});

var tambahData = ()=>
$(document).ready(function(){
        $(".test15").hide(800);
        $(".tambahProgram").show(800);
});

</script>

<div class="container">
<center>
    <h4>Usulan Rencana Kegiatan dan Anggaran Tahun 2020</h4>
    <i><h8>Program Studi : Diploma 4 Teknologi Rekayasa Perangkat Lunak</h8></i>
</center>
<hr>
            <form action="<?php echo e(('tambah2')); ?>" method="" class="">
                <div class="row">
                        <div class="col-md-12 form-tambah row">
                            <div class="col-md-12"><center><b><p> Visi </p></b></center></div>
                            <div class="col-md-12"><textarea name="" id=""class="form-control" placeholder="Ketik disini.." cols="30" rows="10"></textarea></div>
                        </div>
                        <div class="col-md-12 form-tambah row">
                            <div class="col-md-12"><center><b><p> Misi </p></b></center></div>
                            <div class="col-md-12"><textarea name="" id="" cols="30" rows="10" placeholder="Ketik disini.." class="form-control"></textarea></div>
                        </div> 
                        <div class="col-md-12 form-tambah row">
                            <div class="col-md-10"></div>
                            <div class="col-md-2"><input type="submit" name=""  value="Selanjutanya" class="btn-tema" id=""></div>
                        </div>            
                </div>
            </form>
</div>

</head>
<body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA2\resources\views/program/tambah.blade.php ENDPATH**/ ?>