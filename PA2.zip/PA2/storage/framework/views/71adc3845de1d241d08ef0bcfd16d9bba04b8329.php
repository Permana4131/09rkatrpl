 
 
<?php $__env->startSection('judul_halaman', 'Halaman Home'); ?>
 
<?php $__env->startSection('konten'); ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA2\resources\views/homeAdmin.blade.php ENDPATH**/ ?>