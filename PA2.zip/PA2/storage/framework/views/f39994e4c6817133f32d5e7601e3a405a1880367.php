 
 
<?php $__env->startSection('konten'); ?>
<script>
var tambahData = ()=>
$(document).ready(function(){
        $(".npk-baru").show(800);
});
var hapus = ()=>
$(document).ready(function(){
        $("#i").hide();
        $("#ic").hide();
});
</script>

<div class="container">
<h4>Edit Program</h4>
<hr>
            <form action="" class="test15" method="">
                <div class="row">
                    <div class="col-md-12 text">
                        <h3>Data Program</h3>
                    </div>
                    <div class="col-md-12 edit-program">
                            <div class="col-md-12 row in">
                                <div class="col-md-4"><p>Standar</p></div>
                                <div class="col-md-8"><input type="text" class="input-text" value="" name="" id=""></div>
                            </div>  
                            <div class="col-md-12 row in">
                                <div class="col-md-4"><p>Mata Anggaran</p></div>
                                <div class="col-md-8"><input type="text" class="input-text" value="II.4.1" name="" id=""></div>
                            </div>   
                            <div class="col-md-12 row in">
                                <div class="col-md-4"><p>Nama Program dan Kegiatan</p></div>
                                <div class="col-md-8"><input type="text" class="input-text" value="Rekrutmen pegawai" name="" id=""></div>
                                
                            </div>   
                            <div class="col-md-12 row">
                                <div class="col-md-4"></div>
                                <div class="col-md-8">
                                        <div class="row">
                                            <?php for($i=1; $i<5 ;$i++){ ?>
                                                <div class="col-md-5">
                                                    <input type="text" class="input-text" id="i" value="Rekrutmen satu orang pegawai administrasi Jurusan" class="input text">
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="button" class="icon-times " id="ic" value="x" onclick="hapus()">
                                                    <!-- <button class="icon-times"><span class="fa fa-times i"></span></button> -->
                                                </div>
                                            <?php } ?>
                                        </div>
                                </div>
                                <div class="col-md-4"></div>
                                <div class="col-md-2"><input type="button" class="icon-times"  onclick="tambahData()" value="Tambah data"></div>
                                <div class="col-md-6 npk-baru"><input type="text" class="input-text" placeholder="Masukkan data baru"></div>
                            </div>
                            <div class="col-md-12 row in">
                                <div class="col-md-4"><p>Tujuan Kegiatan</p></div>
                                <div class="col-md-8"><input type="text" class="input-text" value="Menempati posisi admin jurusan yang bertugas" name="" id=""></div>
                            </div>  
                            <div class="col-md-12 row in">
                                <div class="col-md-4"><p>Target Luaran/Peserta Kegiatan</p></div>
                                <div class="col-md-8"><input type="text" class="input-text" name="" id=""></div>
                            </div>    
                            <div class="col-md-12 row in">
                                <div class="col-md-4"><p> Sasaran Kegiatan/Peserta Kegiatan</p></div>
                                <div class="col-md-8"><input type="text" class="input-text" name="" id=""></div>
                            </div>
                            <div class="col-md-12 row in">
                                <div class="col-md-4"><p> Vol</p></div>
                                <div class="col-md-8"><input type="text" value="0" class="input-text" name="" id=""></div>
                            </div>         
                            <div class="col-md-12 row in">
                                <div class="col-md-4"><p> Sataun</p></div>
                                <div class="col-md-8"><input type="text" value="orang" class="input-text" name="" id=""></div>
                            </div> 
                            <div class="col-md-12 row in">
                                <div class="col-md-4"><p> Harga Satuan (1000 rupiah)</p></div>
                                <div class="col-md-8"><input type="text" value="0.00" class="input-text" name="" id=""></div>
                            </div> 
                             <div class="col-md-12 row in">
                                <div class="col-md-4"><p> Jumlah(10000)</p></div>
                                <div class="col-md-8"><input type="text" class="input-text" name="" id=""></div>
                            </div>
                       
                    </div> 
                    <div class="col-md-12 row">
                        <div class="col-md-8"></div>
                        <div class="col-md-2 bt"><input type="button" class="btn-tema2" value="Batal" name="" id=""></div>
                        <div class="col-md-2 bt"><input type="button" class="btn-tema2" value="Simpan" name="" id=""></div>
                    </div>
                </div>
            </form>
</div>

</head>
<body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA2\resources\views/program/edit.blade.php ENDPATH**/ ?>