
 
 
 
<?php $__env->startSection('konten'); ?>
<script>


var hapus = ()=>
$(document).ready(function(){
    var r = confirm("Yakin ingin menghapus data ini??");
    if (r === false) {
           alert("Batal menghapus data");
        }else{
            alert("Sukses menghapus data");
        }
});

</script>
 
 <div class="container-fluid tableProgram">
 <div class="col-md-12"><center><h2>Anggarann  Program Tahun 2020</h2></center></div>
        <div class="col-md-12 form-tambah row">
        <?php if(session()->get('role')=="KA"){ ?>
        <div class="col-md-8"><input type="button" class="btn-tema" value="Revisi"></div>
        <?php } ?>
        <?php if(session()->get('role')=="Mahasiswa"){ ?>
            <div class="col-md-8"></div>
        <?php } ?>
            <div class="col-md-2"><input type="text" placeholder="Cari" class="form-control"></div>
            <div class="col-md-2">
               <input type="button"  class="btn-tema2" value="Cari">
            </div>
        </div>
    <div class="col-md-12 ">
        <table border="1" class="tableDaftarProgram">
            <th width="1%">No</th>
            <th width="3%">Standar</th>
            <th width="3%">Mata Anggaran</th>
            <th width="5%">Nama Program dan Kegiatan</th>
            <th width="3%">Tujuan Kegiatan</th>
            <?php if(session()->get('role')=="KA"){ ?>
            <th width="10%">Target Luaran/Peserta Kegiatan</th>
            <?php }?>
            <?php if(session()->get('role')=="Mahasiswa"){ ?>
            <th width="15%">Target Luaran/Peserta Kegiatan</th>
            <?php } ?>
            <th width="10%">Sasaran Kegiatan/Peserta Kegiatan</th>
            <th width="2%">Vol</th>
            <th width="5%">Satuan</th>
            <th width="5%">Harga Satuan (1000 rupiah)</th>
            <th width="5%">Jumlah(10000)</th>
            <?php if(session()->get('role')=="KA"){ ?>
                <th width="5%">Aksi</th>
            <?php } ?>
        
            
            <?php for($i=1;$i<6;$i++){ ?>
                <tr>
                    <td class="no"><?php echo $i ?></td>
                    <td></td>
                    <td><?php echo "II.4.".$i ?></td>
                    <td>Maya Anggaran</td>
                    <td>Tujuan Kegiatan</td>
                    <td>Target Luaran/Peserta Kegiatan</td>
                    <td>Sasaran Kegiatan/Peserta Kegiatan</td>
                    <td>Vol</td>
                    <td>Sataun</td>
                    <td>Harga Satuan (1000 rupiah)</td>
                    <td>Jumlah(10000)</td>
                    <?php if(session()->get('role')=="KA"){ ?>
                    <td>
                    <div class="col">
                        <div class="col-md-6">
                            <a href="<?php echo e(Route('editProgram')); ?>"><input type="button" class="btn-act" value="Edit"></a>                                     
                        </div>
                        <div class="col-md-6">
                            <input type="button" class="btn-act" onclick="hapus()" id="hapus" name="hapus" value="Hapus"> 
                            
                        </div>
                    </div>
                    </td>
                    <?php } ?>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>
                        <table class="table2">
                            <tr>
                                <td class="id"><?php echo "II.4.".$i.".1"?></td> 
                            
                                    <td>
                                        <table>
                                        <?php for($y=1;$y<6;$y++){ ?>  
                                            <tr>
                                                <td>-ss</td>
                                            </tr>
                                            <?php } ?>
                                        </table>
                                    </td>    
                           

                            </tr>
                        </table>
                    </td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <?php if(session()->get('role')=="KA"){ ?>
                    <td></td> 
                    <?php } ?>
                </tr>
            <?php } ?>
        </table>
    </div>
 </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA2\resources\views/daftarProgram.blade.php ENDPATH**/ ?>