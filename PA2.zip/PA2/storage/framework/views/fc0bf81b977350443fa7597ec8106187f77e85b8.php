 
 
<?php $__env->startSection('konten'); ?>
<script>
var tambahData = ()=>
$(document).ready(function(){
        $(".npk-baru").show(800);
});
var hapus = ()=>
$(document).ready(function(){
        $("#i").hide();
        $("#ic").hide();
});

var kirim = ()=>
$(document).ready(function(){
    var r = confirm("Yakin ingin mengirim data??");
    if (r === false) {
           alert("Batal mengirim data");
        }else{
            alert("Data sukses dikirim silahkan tunggu proses selanjutnya");
            window.location.href = "/home"
        }
});
</script>

<div class="container">
<center><h2>Tambah Data Program</h2></center>
<hr>
            <form action="" class="test15" method="">
                <div class="row">
                    <div class="col-md-12 edit-program">
                            <div class="col-md-12 row in">
                                <div class="col-md-4 p"><p>Standar</p></div>
                                <div class="col-md-8"><input type="text" placeholder="Masukkan data baru" class="input-text" value="" name="" id=""></div>
                            </div>  
                            <div class="col-md-12 row in">
                                <div class="col-md-4 p"><p>Mata Anggaran</p></div>
                                <div class="col-md-8"><input type="text" placeholder="Masukkan data baru" class="input-text"  name="" id=""></div>
                            </div>   
                            <div class="col-md-12 row in">
                                <div class="col-md-4 p"><p>Nama Program dan Kegiatan</p></div>
                                <div class="col-md-8"><input type="text" placeholder="Masukkan data baru" class="input-text" name="" id=""></div>
                                
                            </div>   
                            <div class="col-md-12 row">
                                <div class="col-md-4"></div>
                                <div class="col-md-8">
                                        <div class="row">
                                            <?php for($i=1; $i<5 ;$i++){ ?>
                                                <div class="col-md-5">
                                                    <input type="text" placeholder="Masukkan data baru" class="input-text" id="i"  class="input text">
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="button" class="icon-times " id="ic" value="x" onclick="hapus()">
                                                    <!-- <button class="icon-times"><span class="fa fa-times i"></span></button> -->
                                                </div>
                                            <?php } ?>
                                        </div>
                                </div>
                                <div class="col-md-4"></div>
                                <div class="col-md-2"><input type="button" class="icon-times btn-tema2"  onclick="tambahData()" value="Tambah data"></div>
                                <div class="col-md-6 npk-baru"><input type="text" placeholder="Masukkan data baru" class="input-text" placeholder="Masukkan data baru"></div>
                            </div>
                            <div class="col-md-12 row in">
                                <div class="col-md-4 p"><p>Tujuan Kegiatan</p></div>
                                <div class="col-md-8">
                                <div class="row">
                                            <?php for($i=1; $i<5 ;$i++){ ?>
                                                <div class="col-md-5">
                                                    <input type="text" placeholder="Masukkan data baru" class="input-text" id="i"  class="input text">
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="button" class="icon-times " id="ic" value="x" onclick="hapus()">
                                                    <!-- <button class="icon-times"><span class="fa fa-times i"></span></button> -->
                                                </div>
                                            <?php } ?>
                                            <div class="col-md-5 npk-baru"><input type="text" placeholder="Masukkan data baru" class="input-text" placeholder="Masukkan data baru"></div>
                                        </div>
                                </div>
                            </div> 
                            <div class="col-md-12 row in">
                                <div class="col-md-4 p"><p>Target Luaran/Peserta Kegiatan</p></div>
                                <div class="col-md-8"><input type="text"placeholder="Masukkan data baru" class="input-text" name="" id=""></div>
                            </div>    
                            <div class="col-md-12 row in">
                                <div class="col-md-4 p"><p> Sasaran Kegiatan/Peserta Kegiatan</p></div>
                                <div class="col-md-8"><input type="text" placeholder="Masukkan data baru" class="input-text" name="" id=""></div>
                            </div>
                            <div class="col-md-12 row in">
                                <div class="col-md-4 p"><p> Vol</p></div>
                                <div class="col-md-8"><input type="text" placeholder="Masukkan data baru" class="input-text" name="" id=""></div>
                            </div>         
                            <div class="col-md-12 row in">
                                <div class="col-md-4 p"><p> Sataun</p></div>
                                <div class="col-md-8"><input type="text" placeholder="Masukkan data baru" class="input-text" name="" id=""></div>
                            </div> 
                            <div class="col-md-12 row in">
                                <div class="col-md-4 p"><p> Harga Satuan (1000 rupiah)</p></div>
                                <div class="col-md-8"><input type="text" placeholder="Masukkan data baru" class="input-text" name="" id=""></div>
                            </div> 
                             <div class="col-md-12 row in">
                                <div class="col-md-4 p"><p> Jumlah(10000)</p></div>
                                <div class="col-md-8"><input type="text" placeholder="Masukkan data baru" class="input-text" name="" id=""></div>
                            </div>
                       
                    </div> 
                    <div class="col-md-12 row">
                        <div class="col-md-8"></div>
                        <div class="col-md-2 bt"><input type="button" onclick="kirim()" class="btn-tema2" value="Kirim" name="" id=""></div>
                        <div class="col-md-2 bt"><input type="button" class="btn-tema2" value="Selanjutnya" name="" id=""></div>
                    </div>
                </div>
            </form>
</div>

</head>
<body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA2\resources\views/program/tambahpage2.blade.php ENDPATH**/ ?>