 
 
<?php $__env->startSection('konten'); ?>
<script>
$(document).ready(function(){
  $("cari").click(function(){
    $("p").toggle(1000);
  });
});

var daftarKegiatan = ()=>
$(document).ready(function(){
        $(".request-kegiatan").hide(800);
        $(".test15").show(800);  

});

var tambahData = ()=>
$(document).ready(function(){
        $(".test15").hide(800);
        $(".request-kegiatan").show(800);
});

var kirim = ()=>
$(document).ready(function(){
    var r = confirm("Yakin ingin mengirim Permohonan??");
    if (r === false) {
           alert("Batal mengirim Permohonan");
        }else{
            alert("Permohonan sukses dikirim silahkan tunggu proses selanjutnya");
            window.location.href = "/home"
        }
});



</script>

<div class="container">
<h4>Tmabah Program</h4>
<hr>
    <form action="" method="post" class="form-tambah">
                <div class="row">
                    <div class="col-lg-12">
                        <input type="button" id="btn" class="btn-tema" onclick="tambahData()" value="Tambahkan Program Kegiatan">
                        <input type="button" id="btn" class="btn-tema" onclick="daftarKegiatan()" value="Lihat daftar kegiatan">
                    </div>    
                </div>
            </form>
            <form action="" class="test15" method="post">
                <div class="row">
                    <div class="col-md-12 text">
                        <h3>Program Sebelumnya</h3>
                    </div>
                    <div class="col-md-12">
                    <table class="table-request">
                        <th width="2%">No</th>
                        <th width="20%">Status Persetujuan</th>
                        <th width="20%">Oleh</th>
                        <th width="40">Kegiatan</th>
                        <th width="18">Dana</th>
                        <th width="2%">Aksi</th>
                        <?php for($i=1;$i<6;$i++){ ?>
                            <tr>
                                <td>
                                    <p><?php echo $i ?></p>
                                </td>
                                <td>
                                    <p>Disetjui</p>
                                </td>
                                <td>
                                    <p>KA Prodi</p>
                                </td>
                                <td>Kegiatan HIMAPRO(Welcoming Pary Anggaran 2019)</td>
                                <td>Rp 1.000.000</td>
                                <td>
                                <nav id="sticker" class="navbar navbar-expand-lg">
                                    <ul class="navbar-nav">
                                        <li class="nav-item dropdown">
                                        <a class="nav-link" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <span class="fa fa-wrench">tools</span>
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                        <a class="dropdown-item" href="#">Lihat</a>
                                        <a class="dropdown-item" href="#">Cetak</a>                
                                        </li>
                                    </ul>
                                </nav>
                        </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </table>
                    </div>
                </div>
            </form>

            <form action=""  class="request-kegiatan" method="">
                <div class="row">
                    <div class="col-md-12 edit-program">
                            <div class="col-md-12 row req">
                               <div class="col-md-4"><p>Tahun Anggaran</p></div>
                               <div class="col-md-2">
                                   <select name="" id="" class="input-text">
                                       <option value="2019">2019</option>
                                       <option value="2020">2020</option>
                                   </select>
                               </div>
                               <div class="col-md-6"> </div>
                            </div>
                            <div class="col-md-12 row req">
                                <div class="col-md-4"> <p>Tanggal</p></div>
                                <div class="col-md-8">
                                    <input class="input-date" type="date">
                                </div>
                            </div>
                            <div class="col-md-12 row req">
                                <div class="col-md-4"> <p>Unit</p></div>
                                <div class="col-md-8"><input type="text" class="input-text"></div>
                            </div>
                            <div class="col-md-12 row req">                    
                                <div class="col-md-4"><p>Nominal</p></div>
                                <div class="col-md-8"><p>Rp 1.000.000 - Rp 10.000.000</p></div>
                            </div>
                            <hr>
                            <div class="col-md-12">
                               <table border="1">
                                   <th width="4%">No</th>
                                   <th width="40%">Keterangan</th>
                                   <th width="28%">Jumlah</th>
                                   <th width="19%">Size</th>
                                   <th width="17%">Kode Budget</th>
                                   <?php for($i=1;$i<4;$i++){ ?>
                                   <tr>
                                       <td class="no"><?php echo $i ?></td>
                                       <td><input type="text" class="input-text" placeholder="Ketik disini.."></td>
                                       <td><input type="text" class="input-text" placeholder="Ketik disini.."></td>
                                       <td><input type="text" class="input-text" placeholder="Ketik disini.."></td>
                                       <td><input type="text" class="input-text" placeholder="Ketik disini.."></td>
                                   </tr>
                                   <?php }?>
                                   <tr class="end">
                                       <td colspan="2">Total</td>
                                       <td></td>
                                       <td></td>
                                       <td></td>
                                   </tr>
                               </table>
                            </div>     
                    </div> 
                    <div class="col-md-12 row">
                        <div class="col-md-10"></div>
                        <div class="col-md-2 bt"><input type="button" class="btn-tema2" onclick="kirim()" value="Kirim" name="" id=""></div>
                    </div>
                </div>
            </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA2\resources\views/mahasiswa/requestKegiatan.blade.php ENDPATH**/ ?>