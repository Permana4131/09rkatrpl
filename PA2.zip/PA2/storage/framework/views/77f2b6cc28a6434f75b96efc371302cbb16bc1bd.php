 
 
<?php $__env->startSection('konten'); ?>
<header>
	<div class="navbar" role="navigation">
		<div class="container">
    	<div class="navbar-header">
      </div>
      <div class="collapse navbar-collapse" id="mynav">
      	<ul class="nav navbar-nav navbar-right">
        	<li><a href="#about">About</a></li>
          <li><a href="#clients">Clients</a></li>
          <li><a href="#process">Process</a></li>
          <li><a href="#testimonials">Testimonials</a></li>
          <li><a href="#blogs">Blogs</a></li>
        </ul>
      </div>
     </div>	
	</div>
    <!-- <div class="banner">
      <h2>We help you achieve your goals</h2>
      <div class="info">
        <a href="#process" title="">See our process</a>
        <a href="#clients" title="">See our clients</a> 
      </div>
    </div> -->
 </header>
  
<div class="container">
<?php if(session()->get('role')=="KA"){ ?>
<div class="col-md-12"><a href="<?php echo e(route('tambahProgram')); ?>"><input type="button" class="btn-tema2" value="Tambah Program" name="" id=""></a></div>
<?php } ?>   
<fieldset class="scheduler-border">
        <legend class="scheduler-border"><p>Daftar Program Kegiaan dan Anggaran D4TRPL</p></legend>
        <div class="container-fluid row program-content"> 
            <?php for($i=0;$i<4;$i++){ ?>
            <a class="as" href="/programKegiatan/daftarProgram">
            <div class="col-md-12 programKegiatan">
            <div class="row"> 
                <div class="col-md-2 pk">
                    <p>2019/2020</p>
                </div>
                <div class="col-md-10">
                    <div class="row">
                    <div class="col-md-5"><p>Jumlah Program Kegiatan :</p></div>
                    <div class="col-md-3"><p>14</p></div> 
                    </div>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <div class="row">
                    <div class="col-md-5"><p>Total Dana</p></div>
                    <div class="col-md-3"><p>Rp. 100.000.000</p></div> 
                    </div>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <div class="row">
                    <div class="col-md-5"><p>Terpakai</p></div>
                    <div class="col-md-3"><p>Rp. 80.000.000</p></div> 
                    </div>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-2"></div>
                 <div class="col-md-8">
                    <div class="row">
                    <div class="col-md-5"><p>Dana</p></div>
                    <div class="col-md-3"><p>Rp. 20.000.000</p></div> 
                    </div>
                </div>
                <div class="col-md-2"></div>
                
            </div>
            </div>
            </a>
            <?php } ?>
        </div>
        <div class="col-md-12 test"><p><< 1 >></p></div>
    </fieldset>
    <fieldset>
    
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\D4-TRPL\Semester 4\Proyek Akhir Tahun II (4)\Week_13\Praktikum\PA2\resources\views/programKegiatan.blade.php ENDPATH**/ ?>